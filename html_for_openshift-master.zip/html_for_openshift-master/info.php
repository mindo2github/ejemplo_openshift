<?php echo "Servidor:"; echo gethostname();echo "\n"; ?>
